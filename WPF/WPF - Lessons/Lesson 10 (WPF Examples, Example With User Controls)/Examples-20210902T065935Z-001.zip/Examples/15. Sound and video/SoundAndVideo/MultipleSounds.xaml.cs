using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SoundAndVideo
{
    /// <summary>
    /// Interaction logic for MultipleSounds.xaml
    /// </summary>

    public partial class MultipleSounds : System.Windows.Window
    {

        public MultipleSounds()
        {
            InitializeComponent();
        }

    }
}