#include<iostream>
#include "Start.h"
using namespace std;



void Run() {
	Start();
}

void main() {
	Run();
}