#pragma once

#include<iostream>
using namespace std;
#include "Entities.h"

void ShowHuman(const Human& human) {
	cout << "Name : " << human.name << endl;
	cout << "Phone : " << human.phonenumber << endl;
	cout << "Create Date : " << human.createdDate << endl;
}

void ShowAll(const Contact& contact) {
	for (size_t i = 0; i < contact.count; i++)
	{
		ShowHuman(*contact.humans[i]);
		cout << endl;
	}
}

Human* GetNewHuman() {
	char* name = new char[100]{};
	cin.ignore();
	cin.clear();
	cout << "Enter name : " << endl;
	cin.getline(name, 100);

	char* number = new char[100]{};
	cout << "Enter number : " << endl;
	cin.getline(number, 100);

	Human* human = new Human{ name,number,__DATE__ };
	return human;
}
void AddNewHuman(Contact& contact, const Human& human) {
	int count = contact.count;
	auto newhumans = new Human * [count + 1]{};
	for (size_t i = 0; i < count; i++)
	{
		newhumans[i] = contact.humans[i];
	}
	newhumans[count] = new Human{ human };
	contact.humans = newhumans;
	newhumans = NULL;
	contact.count++;
	cout << "New contact added successfully" << endl;
}


void SortAToZ(Contact& contact, bool reverse = false) {
	int data = 1;
	if (reverse) {
		data = -1;
	}
		for (size_t i = 0; i < contact.count - 1; i++)
		{
			for (size_t k = 0; k < contact.count - i - 1; k++)
			{
				if (strcmp(contact.humans[k]->name, contact.humans[k + 1]->name) == data) {
					auto temp = contact.humans[k];
					contact.humans[k] = contact.humans[k + 1];
					contact.humans[k + 1] = temp;
				}
			}
		}

}



