#pragma once
#include<iostream>
using namespace std;

void CreateFile() {
	cout << "File created" <<__FILE__<< endl;
}


void WriteFile() {
	cout << "Data was writed successfully" << endl;
}
