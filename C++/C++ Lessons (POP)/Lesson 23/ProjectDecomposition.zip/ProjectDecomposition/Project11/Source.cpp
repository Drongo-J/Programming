﻿//#include<iostream>
//using namespace std;
//



//struct Student {
//	char* name;
//	int age;
//};


//void Something(Student* s) {
//	s->age = 555;
//	//cout << s.age << endl;
//}
//
//
//void main() {
//Student *s=new Student{ new char[] {"John"},10 };
//cout << s->age << endl;
//Something(s);
//cout << s->age << endl;
//
//
//}


//void Something(Student& s) {
//	s.age = 555;
//	//cout << s.age << endl;
//}
//
//
//void main() {
//	Student* s = new Student{ new char[] {"John"},10 };
//	cout << s->age << endl;
//	Something(*s);
//	cout << s->age << endl;
//}


#include<iostream>
using namespace std;

//#define Pi 3.141516
//
//#define Name "Elvin"
//void main() {
//	int a = 100;
//	//cout << Pi << endl;
//	cout << Name << endl;
//}


//#define Əsas main
//
//#define Boş void
//#define Başla {
//#define Son }
//#define Çap cout <<
//#define Dövr while
//#define Tam int
//#define Artır ++
//
//
//
//Boş Əsas() Başla
//Tam eded = 0;
//			Dövr(eded<5)
//				Başla
//			Çap "Salam" << endl;
//			eded Artır;
//			Son
//Son

//#define Linux
//
//#ifdef Windows
//void dosomething() {
//	cout << "this code works only Windows" << endl;
//}
//#endif 
//#ifdef Linux
//void dosomething() {
//	cout << "this code works only Linux" << endl;
//}
//#endif 
//
//
//void main() {
//
//	dosomething();
//}


//
//#define Size 65
//
//
//#if Size>50
//void something() {
//	cout << "I am working for big data" << endl;
//	  }
//#endif
//#if Size<=30
//void something() {
//	cout << "I am working for normal data" << endl;
//}
//#endif
//
//
//void main() {
//	something();
//}



//#define MILLISECONDS(age) (age * 365 * 24 * 60 * 60 * 1000)
//
//int main()
//{
//	/* The age of TechOnTheNet in milliseconds */
//	int age;
//
//#if INT_MAX < MILLISECONDS(12)
//#error Integer size cannot hold our age in milliseconds
//#endif
//
//	/* Calculate the number of milliseconds in 12 years */
//	age = MILLISECONDS(12);
//
//	printf("TechOnTheNet is %d milliseconds old\n", age);
//
//	return 0;
//}


//void main() {
//
//
//	cout << "Current date : " << __DATE__ << endl;
//	cout << "Current time : " << __TIME__ << endl;
//	cout << "Current file : " << __FILE__ << endl;
////#line 1
//	cout << "Current code line : " << __LINE__ << endl;
//	cout << "Current code line : " << __LINE__ << endl;
//	cout << "Current code line : " << __LINE__ << endl;
//	cout << "Current code line : " << __LINE__ << endl;
//}
//
//
//


//#pragma region DatabaseCodes
//void ConnectToDb() {
//
//
//
//}
//
//
//void CreateSeedData() {
//
//
//
//
//}
//
//
//
//void DeleteDb() {
//
//
//
//}
//#pragma endregion
#include "Database.h"

void Start() {
	cout << "Program started" << endl;
	ConnectToDatabase();

}

void main() {
	Start();
}