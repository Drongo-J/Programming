#pragma once
#include<iostream>
#include "FileHelper.h"
using namespace std;


void ConnectToDatabase() {
	cout << "Connected Succesfully" << endl;
	cout << "Date : " << __DATE__ << " : " << __TIME__ << endl;
	CreateFile();
	WriteFile();
}
