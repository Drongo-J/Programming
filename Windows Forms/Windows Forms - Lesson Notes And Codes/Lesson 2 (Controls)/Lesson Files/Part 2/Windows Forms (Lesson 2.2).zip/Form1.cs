﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Lesson2._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = textBox1.Text;
            MessageBox.Show($"This text : {text} send to the client successfully!");
        }

        private void textBox1_MouseEnter(object sender, EventArgs e)
        {
            if (textBox1.Text == "Some Message")
            {
                textBox1.Text = string.Empty;
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_MouseLeave(object sender, EventArgs e)
        {   
            if (textBox1.Text.Trim() == string.Empty)
            {
                textBox1.Text = "Some Message";
                textBox1.ForeColor = Color.Gray;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void passwordTxtb_TextChanged(object sender, EventArgs e)
        {

        }

        private void passwordTxtb_KeyPress(object sender, KeyPressEventArgs e)
        {
            string text = passwordTxtb.Text.Trim();
            if (text.Length > 0 && text.Length <= 6)
            {
                infoLbl.Text = "Your password is so weak";
                infoLbl.ForeColor = Color.Red;
            }
            else if (text.Length >= 7 && text.Length <= 14)
            {
                infoLbl.Text = "Your password is normal";
                infoLbl.ForeColor = Color.Orange;
            }
            else if (text.Length >= 15 && text.Length <= 20)
            {
                infoLbl.Text = "Your password is so strong";
                infoLbl.ForeColor = Color.Green;
            }
        }
    }
}
