﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Lesson1
{
    public partial class Form1 : Form
    {

        Timer timer = new Timer();
        public Form1()
        {
            InitializeComponent();

            timer.Interval = 1000;
            timer.Tick += Timer_Tick;

            timer.Start();

            Label loginLbl = new Label();
            loginLbl.Location = new Point(200, 150);
            loginLbl.ForeColor = Color.Aqua;
            loginLbl.Text = "Hello New Label";
            loginLbl.Font = new Font("Comic Sans Ms", 36, FontStyle.Bold);
            loginLbl.AutoSize = true;

            //button1.Text = "Click Me";
            //button1.ForeColor = Color.Green;
            //button1.BackColor = Color.Red;

            this.Controls.Add(loginLbl);
            //this.Controls.Add(button1);
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            this.Text = DateTime.Now.ToLongTimeString();
            this.label1.Text = DateTime.Now.ToLongTimeString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //label1.Text = "You Clicked Button";

            if (sender is Button bt)
            {
                bt.Dispose();

                Button button = new Button();

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            height = button1.Height;
            width = button1.Width;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Scroll(object sender, ScrollEventArgs e)
        {

        }
        int height = 0;
        int width = 0;
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            //label2.Text = $"X : {e.X} Y : {e.Y}";
            //label2.Font = new Font("Comic Sans Ms", 36, FontStyle.Bold);

            // 1
            //button1.Location = new Point(e.X, e.Y);
            //button1.Text = "Click Me";
            //button1.ForeColor = Color.Green;
            //button1.BackColor = Color.Red;

            // 2
            button1.Location = new Point(e.X, e.Y);
            //button1.Width = button1.Width + e.X /100;
            //button1.Height = button1.Height + e.X / 100;

            button1.Height = height + e.X;
            button1.Width = width + e.X;


            //button.Dispose();

            //int width = this.Size.Width;

            //if (e.X >= 0 && e.X <= width / 4)
            //{
            //    this.BackColor = Color.Blue;
            //}
            //else if (e.X >= width / 4 && e.X <= (width / 4) * 2)
            //{
            //    this.BackColor = Color.Red;
            //}
            //else if (e.X >= (width / 4) * 2 && e.X <= (width / 4) * 3)
            //{
            //    this.BackColor = Color.Green;
            //}
            //else if (e.X >= (width / 4) * 3 && e.X <= width)
            //{
            //    this.BackColor = Color.Yellow;
            //}
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            //this.BackColor = Color.Red;
            //MessageBox.Show("Mouse Down");
        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            //this.BackColor = Color.OldLace;
        }
    }
}
