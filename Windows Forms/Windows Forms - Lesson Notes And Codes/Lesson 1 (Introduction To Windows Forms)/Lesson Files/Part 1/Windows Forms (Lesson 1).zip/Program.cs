﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Lesson1
{
    public static class Program
    {
        static DialogResult GetDialogResult()
        {
            DialogResult result;
            string message = "Window Is Displaying A Text Message";
            string caption = "C# Language";
            //result = MessageBox.Show(message);
            //result = MessageBox.Show(message, caption, MessageBoxButtons.OKCancel);
            result = MessageBox.Show(message, caption, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Warning);
            return result;
        }


        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //var result = GetDialogResult();

            //if (result == DialogResult.OK)
            //{
            //    MessageBox.Show("You Clicked To OK");
            //}
            //else if (result == DialogResult.Cancel)
            //{
            //    MessageBox.Show("Yout Clicked To Cancel");
            //}

            //if (result == DialogResult.Abort)
            //{
            //    MessageBox.Show("You Aborted");
            //}
            //else if (result == DialogResult.Ignore)
            //{
            //    MessageBox.Show("You Ignored");
            //}
            //else if (result == DialogResult.Retry)
            //{
            //    MessageBox.Show("You Retried");

            Application.Run(new Form1());

        }
    }
}
