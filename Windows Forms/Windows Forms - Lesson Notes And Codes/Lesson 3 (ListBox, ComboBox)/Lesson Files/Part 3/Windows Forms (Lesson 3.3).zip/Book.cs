﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsForms_Lesson3._3
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public string Genre { get; set; }


        public override string ToString()
        {
            return $"Title : {this.Title} Book : {this.Author} Genre : {this.Genre}";
        }

    }
}
