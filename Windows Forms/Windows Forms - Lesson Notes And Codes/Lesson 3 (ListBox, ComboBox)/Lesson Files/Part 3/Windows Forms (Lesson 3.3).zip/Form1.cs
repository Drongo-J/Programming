﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Lesson3._3
{
    public partial class Form1 : Form
    {
        List<Book> books;
        public Form1()
        {
            InitializeComponent();
            books=new List<Book>();
            Book book1 = new Book()
            {
                Title = "Book 1",
                Author = "Author 1",
                Genre = "Crime"
            };
            Book book2 = new Book()
            {
                Title = "Book 2",
                Author = "Author 2",
                Genre = "Comedy"
            };
            Book book3 = new Book()
            {
                Title = "Book 3",
                Author = "Author 3",
                Genre = "Drama"
            };
            Book book4 = new Book()
            {
                Title = "Book 4",
                Author = "Author 4",
                Genre = "Comedy"
            };
            Book book5 = new Book()
            {
                Title = "Book 5",
                Author = "Author 5",
                Genre = "Fiction"
            };
            Book book6 = new Book()
            {
                Title = "Book 6",
                Author = "Author 6",
                Genre = "Classic"
            };
            Book book7 = new Book()
            {
                Title = "Book 7",
                Author = "Author 7",
                Genre = "Fiction"
            };
            Book book8 = new Book()
            {
                Title = "Book 8",
                Author = "Author 8",
                Genre = "Classic"
            };
            Book book9 = new Book()
            {
                Title = "Book 9",
                Author = "Author 9",
                Genre = "Comedy"
            };

            books.Add(book1);
            books.Add(book2);
            books.Add(book3);
            books.Add(book4);
            books.Add(book5);
            books.Add(book6);
            books.Add(book7);
            books.Add(book8);
            books.Add(book9);

            //booksBox.DisplayMember = nameof(Book.Title);
            foreach (var book in books)
            {
                booksBox.Items.Add(book);
            }

            var result = books.Select(book => book.Genre).ToList().Distinct();
            //result.Distinct();
            //foreach (var book in books)
            //{
            //    booksBox.Items.Add($"Title : {book.Title} Book : {book.Author} Genre : {book.Genre}");

            //}

            genresCbox.Items.Add("All");
            genresCbox.Items.AddRange(result.ToArray());
            //foreach (var genre in result)
            //{
            //    if (!genresCbox.Items.Contains(genre))
            //        genresCbox.Items.Add(genre);
            //}
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var genre = genresCbox.SelectedItem as string;
            booksBox.Items.Clear();
            if (genre == "All")
            {
                booksBox.Items.AddRange(books.ToArray());
            }
            else
            {
                booksBox.Items.Clear();
                booksBox.Items.AddRange(books.Where(b=>b.Genre==genre).ToArray());
            }
        }
    }
}
