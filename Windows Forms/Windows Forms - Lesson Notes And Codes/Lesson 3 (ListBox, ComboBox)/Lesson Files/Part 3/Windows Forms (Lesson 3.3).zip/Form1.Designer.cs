﻿namespace WindowsForms_Lesson3._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.genresCbox = new System.Windows.Forms.ComboBox();
            this.booksBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // genresCbox
            // 
            this.genresCbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.genresCbox.FormattingEnabled = true;
            this.genresCbox.Location = new System.Drawing.Point(486, 16);
            this.genresCbox.Name = "genresCbox";
            this.genresCbox.Size = new System.Drawing.Size(240, 32);
            this.genresCbox.TabIndex = 1;
            this.genresCbox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // booksBox
            // 
            this.booksBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.booksBox.FormattingEnabled = true;
            this.booksBox.ItemHeight = 20;
            this.booksBox.Location = new System.Drawing.Point(12, 12);
            this.booksBox.Name = "booksBox";
            this.booksBox.Size = new System.Drawing.Size(452, 404);
            this.booksBox.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.booksBox);
            this.Controls.Add(this.genresCbox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox genresCbox;
        private System.Windows.Forms.ListBox booksBox;
    }
}

