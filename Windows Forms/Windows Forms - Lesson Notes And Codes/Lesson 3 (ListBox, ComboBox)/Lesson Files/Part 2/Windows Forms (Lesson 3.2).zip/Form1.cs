﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_Lesson3._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            List<string> todos = new List<string>()
            {
                "Read Book",
                "Drink Coffee",
                "Write Code",
                "Write More Code",
                "Play Tennis"
            };

            checkedListBox1.Items.AddRange(todos.ToArray());
            comboBox1.DataSource = todos;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = checkedListBox1.SelectedItem as string;
            if (checkedListBox1.CheckedItems.Contains(item))
            {
                label1.ForeColor = Color.Green;
            }
            else
            {
                label1.ForeColor = Color.Red;
            }
            label1.Text = item;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != String.Empty)
                checkedListBox1.Items.Add(textBox1.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.CheckedItems.Contains(checkedListBox1.Items[i]))
                {
                    checkedListBox1.Items.Remove(checkedListBox1.Items[i]);
                    i--;
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
