﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WindowsForms_Lesson1._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //List<string> cars = new List<string>()
            //{
            //    "Audi",
            //    "Mercedes",
            //    "Chevrolet",
            //    "Bugatti"
            //};

            //listBox1.DataSource = cars;
            //listBox1.SelectedIndex = 2;
            //listBox1.Items.Add("Maserati");
            //listBox1.Items.Add("Wrangler");

            List<Student> students = new List<Student>()
            {
                new Student()
                {
                    Name = "John",
                    Age = 22
                },
                new Student()
                {
                    Name = "Rafig",
                    Age = 23
                },
                new Student()
                {
                    Name = "Tofig",
                    Age = 24
                }
            };

            //listBox1.DataSource = students;
            favouriteList.DisplayMember = nameof(Student.Name);
            listBox1.DisplayMember = nameof(Student.Name);
            listBox1.Items.AddRange(students.ToArray());
            listBox1.SelectedIndex = 0;

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            var selectedItems = listBox1.SelectedItems;
            foreach (var item in selectedItems)
            {
                var student = item as Student;
                label1.Text += $"\n{student.ID} {student.Name} {student.Age}";
            }
            //var selectedItem = favouriteList.SelectedItem as Student;
            //label1.Text = $"{selectedItem.ID}   {selectedItem.Name}, {selectedItem.Age}";

            //label1.Text = selectedItem;
            //MessageBox.Show(selectedItem);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //listBox1.DataSource = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != String.Empty)
            {
                Student student = new Student()
                {
                    Name = textBox1.Text,
                    Age = 0,
                };
                listBox1.Items.Add(student);
            }
            textBox1.Text = String.Empty;
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            var selectedItem = listBox1.SelectedItem as Student;
            if (selectedItem != null)
            {
                label1.Text = $"ID : {selectedItem.ID}\nName : {selectedItem.Name}\nAge : {selectedItem.Age}";
                favouriteList.Items.Add(selectedItem);
                listBox1.Items.Remove(selectedItem);
            }
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
