﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp1.Views;

namespace WindowsFormsApp1.Presenters
{
    public class MainPresenter
    {
        private readonly IMainView _view;

        public MainPresenter(IMainView view)
        {
            _view = view;

            _view.WriteToFileBtnClick += ViewWriteToFileBtnClick;
        }

        public void ViewWriteToFileBtnClick(object sender, EventArgs e)
        {
            string content = _view.NameText + " " + _view.SurnameText;
            File.WriteAllText("Info.txt",content);
        }
    }
}
