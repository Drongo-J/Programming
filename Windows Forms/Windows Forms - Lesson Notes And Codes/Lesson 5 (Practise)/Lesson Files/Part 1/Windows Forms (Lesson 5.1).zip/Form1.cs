﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UC;

namespace WindowsForms_Lesson5._1
{
    public partial class Form1 : Form
    {
        List<Product> products = new List<Product>();
        HomeUC homeUC = new HomeUC();

        public Form1()
        {
            InitializeComponent();

            products.Add(new Product()
            {
                Name = "Asus Rog Strix",
                Price = 1235.60,
                Image = Properties.Resources.asus
            }); ;
            products.Add(new Product()
            {
                Name = "Iphone 11 Pro Max",
                Price = 1500,
                Image = Properties.Resources.iphone
            }); ;
            products.Add(new Product()
            {
                Name = "Zenbook Pro Slim",
                Price = 3200.5,
                Image = Properties.Resources.zenbook
            });
            products.Add(new Product()
            {
                Name = "Samsung",
                Price = 899.9,
                Image = Properties.Resources.samsung
            }); ;

            pictureBox1.Click += guna2Panel1_Click;
            pictureBox2.Click += guna2Panel2_Click;
            label3.Click += guna2Panel1_Click;
            label4.Click += guna2Panel1_Click;

            productsContainer.Controls.Add(homeUC);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void productsContainer_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Panel1_Click(object sender, EventArgs e)
        {
            productsContainer.Controls.Clear();
            productsContainer.Controls.Add(homeUC);
        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Panel2_Click(object sender, EventArgs e)
        {
            this.label2.Text = "Products";
            productsContainer.Controls.Clear();
            int x = 15;
            int y = 10;

            foreach (var item in products)
            {
                var productUC = new ProductUC();
                productUC.Location = new Point(x, y);
                y += 100;


                productUC.Name = item.Name;
                productUC.Price = item.Price;
                productUC.ProductImage = item.Image;

                productUC.DoubleClick += ProductUC_DoubleClick;

                productsContainer.Controls.Add(productUC);
            }
        }

        private void ProductUC_DoubleClick(object sender, EventArgs e)
        {
            this.label2.Text = string.Empty;
            productsContainer.Controls.Clear();
            var product = sender as ProductUC;
            var detailsUC = new DetailUC();
            detailsUC.DetailName = product.Name;
            detailsUC.DetailPrice = product.Price;
            detailsUC.DetailImage = product.ProductImage;

            productsContainer.Controls.Add(detailsUC);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void homeLbl_Click(object sender, EventArgs e)
        {

        }

        private void productsLbl_Click(object sender, EventArgs e)
        {

        }
    }
}
