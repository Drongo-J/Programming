﻿namespace WindowsForms_Lesson5._1
{
    partial class DetailUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            this.detailsNameLbl = new System.Windows.Forms.Label();
            this.detailsPriceLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2CirclePictureBox1
            // 
            this.guna2CirclePictureBox1.ImageRotate = 0F;
            this.guna2CirclePictureBox1.Location = new System.Drawing.Point(96, 3);
            this.guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            this.guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2CirclePictureBox1.Size = new System.Drawing.Size(215, 223);
            this.guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.guna2CirclePictureBox1.TabIndex = 0;
            this.guna2CirclePictureBox1.TabStop = false;
            // 
            // detailsNameLbl
            // 
            this.detailsNameLbl.AutoSize = true;
            this.detailsNameLbl.BackColor = System.Drawing.Color.Transparent;
            this.detailsNameLbl.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.detailsNameLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.detailsNameLbl.Location = new System.Drawing.Point(125, 242);
            this.detailsNameLbl.Name = "detailsNameLbl";
            this.detailsNameLbl.Size = new System.Drawing.Size(74, 30);
            this.detailsNameLbl.TabIndex = 1;
            this.detailsNameLbl.Text = "label1";
            // 
            // detailsPriceLbl
            // 
            this.detailsPriceLbl.AutoSize = true;
            this.detailsPriceLbl.BackColor = System.Drawing.Color.Transparent;
            this.detailsPriceLbl.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.detailsPriceLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.detailsPriceLbl.Location = new System.Drawing.Point(155, 295);
            this.detailsPriceLbl.Name = "detailsPriceLbl";
            this.detailsPriceLbl.Size = new System.Drawing.Size(61, 30);
            this.detailsPriceLbl.TabIndex = 2;
            this.detailsPriceLbl.Text = "label";
            // 
            // DetailUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SpringGreen;
            this.Controls.Add(this.detailsPriceLbl);
            this.Controls.Add(this.detailsNameLbl);
            this.Controls.Add(this.guna2CirclePictureBox1);
            this.Name = "DetailUC";
            this.Size = new System.Drawing.Size(409, 332);
            this.Load += new System.EventHandler(this.DetailUC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2CirclePictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private System.Windows.Forms.Label detailsNameLbl;
        private System.Windows.Forms.Label detailsPriceLbl;
    }
}
