﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UC;

namespace WindowsForms_Lesson5._1
{
    public partial class DetailUC : UserControl
    {
        public string DetailName
        {
            get => detailsNameLbl.Text.ToString();
            set
            {
                detailsNameLbl.Text = value.ToString();
            }
        }

        public double DetailPrice
        {
            get => double.Parse(detailsPriceLbl.Text);
            set
            {
                detailsPriceLbl.Text = value.ToString() + "$";
            }
        }

        public Image DetailImage
        {
            get
            {
                return guna2CirclePictureBox1.Image;
            }
            set
            {
                guna2CirclePictureBox1.Image = value;
            }
        }

        public DetailUC()
        {
            InitializeComponent();
        }

        private void DetailUC_Load(object sender, EventArgs e)
        {

        }
    }
}
